export interface Event {
  id: string;
  title: string;
  description: string;
  longDescription?: string;
  category: string;
  date: string;
  time: string;
  venue: string;
  address?: string;
  image: string;
  price?: string;
  ticketUrl?: string;
  highlights?: string[];
}