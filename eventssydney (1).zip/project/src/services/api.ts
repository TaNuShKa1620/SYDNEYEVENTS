import axios from 'axios';
import { Event } from '../types/event';

// In a real application, these would be actual API calls to your backend
// For this demo, we'll use mock data

const MOCK_EVENTS: Event[] = [
  {
    id: '1',
    title: 'Sydney Symphony Orchestra: Beethoven\'s Fifth',
    description: 'Experience the power and emotion of Beethoven\'s iconic Fifth Symphony at the Sydney Opera House.',
    longDescription: 'Join the Sydney Symphony Orchestra for an unforgettable night of classical music featuring Beethoven\'s Fifth Symphony. The concert opens with Mozart\'s elegant Piano Concerto No. 21, followed by the dramatic and powerful Fifth Symphony - one of the most famous works in classical music. Under the direction of our esteemed conductor and with world-class musicians, this performance promises to be a highlight of Sydney\'s cultural calendar.',
    category: 'Music',
    date: '2025-06-15',
    time: '7:30 PM',
    venue: 'Sydney Opera House',
    address: 'Bennelong Point, Sydney NSW 2000',
    image: 'https://images.pexels.com/photos/164693/pexels-photo-164693.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$85 - $120',
    ticketUrl: 'https://www.sydneyoperahouse.com',
    highlights: [
      'World-renowned Sydney Symphony Orchestra',
      'Featuring Beethoven\'s iconic Fifth Symphony',
      'Special guest pianist for Mozart\'s Piano Concerto',
      'Pre-concert talk with the conductor at 6:30 PM'
    ]
  },
  {
    id: '2',
    title: 'Vivid Sydney Light Festival',
    description: 'The annual festival of light, music and ideas returns to transform Sydney into a wonderland of light art.',
    longDescription: 'Vivid Sydney, the largest festival of light, music, and ideas in the Southern Hemisphere, returns to transform the city into a creative wonderland. For 23 days, Sydney\'s iconic landmarks, public spaces, and buildings will become canvases for extraordinary light installations and projections. Explore illuminated trails through The Rocks and Circular Quay, enjoy contemporary music performances, and engage with thought-provoking talks and workshops.',
    category: 'Festival',
    date: '2025-05-22',
    time: '6:00 PM - 11:00 PM',
    venue: 'Various locations across Sydney',
    address: 'Sydney CBD and surroundings',
    image: 'https://images.pexels.com/photos/1684187/pexels-photo-1684187.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 'Free',
    ticketUrl: 'https://www.vividsydney.com',
    highlights: [
      '3D light projections on the Sydney Opera House',
      'Interactive light installations at Circular Quay',
      'Contemporary music program at Sydney Opera House',
      'Ideas exchange featuring global thought leaders',
      'Family-friendly activities throughout the festival'
    ]
  },
  {
    id: '3',
    title: 'Sydney Food Festival',
    description: 'A celebration of Sydney\'s diverse culinary scene featuring top chefs, food stalls, and cooking demonstrations.',
    longDescription: 'The Sydney Food Festival brings together the city\'s best chefs, restaurateurs, and food producers for a weekend of culinary delights. Sample dishes from over 50 food stalls representing Sydney\'s diverse cultural heritage, watch cooking demonstrations from celebrity chefs, participate in hands-on workshops, and enjoy live music and entertainment. This year\'s festival highlights sustainable food practices and local produce, with special events focused on reducing food waste and supporting local farmers.',
    category: 'Food',
    date: '2025-07-10',
    time: '10:00 AM - 9:00 PM',
    venue: 'Darling Harbour',
    address: 'Darling Harbour, Sydney NSW 2000',
    image: 'https://images.pexels.com/photos/5718071/pexels-photo-5718071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$25 - $45',
    ticketUrl: 'https://www.sydneyfoodfestival.com',
    highlights: [
      'Over 50 food stalls from Sydney\'s best restaurants',
      'Cooking demonstrations from celebrity chefs',
      'Wine and craft beer tastings',
      'Kids\' cooking classes and activities',
      'Live music and entertainment throughout the day'
    ]
  },
  {
    id: '5',
    title: 'Contemporary Art Exhibition: Future Visions',
    description: 'Explore groundbreaking works by emerging Australian artists in this thought-provoking exhibition.',
    longDescription: 'Future Visions brings together works by 15 of Australia\'s most exciting emerging artists, exploring themes of technology, identity, and environmental change. The exhibition features a diverse range of media including digital installations, immersive virtual reality experiences, painting, sculpture, and performance art. Many works are interactive, inviting visitors to become part of the artistic experience. Guided tours are available daily, and the exhibition includes a series of artist talks, workshops, and panel discussions throughout its run.',
    category: 'Arts',
    date: '2025-04-05',
    time: '10:00 AM - 5:00 PM',
    venue: 'Museum of Contemporary Art',
    address: '140 George St, The Rocks NSW 2000',
    image: 'https://images.pexels.com/photos/1509534/pexels-photo-1509534.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$18',
    ticketUrl: 'https://www.mca.com.au',
    highlights: [
      '15 groundbreaking installations by emerging Australian artists',
      'Interactive virtual reality experiences',
      'Daily guided tours included with admission',
      'Artist talks every Saturday at 2:00 PM',
      'Special late-night openings with live performances'
    ]
  },
  {
    id: '6',
    title: 'Sydney Comedy Festival',
    description: 'Get ready to laugh with performances from local and international comedy stars across multiple venues.',
    longDescription: 'The Sydney Comedy Festival returns for its 21st year, bringing together the best local and international comedy talent for three weeks of side-splitting entertainment. From stand-up to sketch, improv to musical comedy, the festival features over 200 performers across multiple venues throughout Sydney. This year\'s headline acts include award-winning comedians from Australia, the UK, and the US, alongside emerging talents in the Sydney Comedy Festival Showcase. Special events include the Comedy Gala, late-night shows, and family-friendly performances during the day.',
    category: 'Comedy',
    date: '2025-04-20',
    time: 'Various times',
    venue: 'Various venues across Sydney',
    address: 'Multiple locations',
    image: 'https://images.pexels.com/photos/7172687/pexels-photo-7172687.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$25 - $65 per show',
    ticketUrl: 'https://www.sydneycomedyfest.com.au',
    highlights: [
      'Over 200 performers across 20+ venues',
      'International headline acts',
      'Opening night Comedy Gala',
      'New Talent Showcase featuring emerging comedians',
      'Family-friendly shows on weekends'
    ]
  },
  {
    id: '7',
    title: 'Hamilton: The Musical',
    description: 'The revolutionary Broadway hit comes to Sydney, telling the story of America\'s founding father Alexander Hamilton.',
    longDescription: 'Experience the musical phenomenon that has taken the world by storm as Hamilton arrives at the Sydney Lyric Theatre. With book, music and lyrics by Lin-Manuel Miranda, Hamilton combines hip-hop, jazz, R&B and Broadway styles to tell the story of American founding father Alexander Hamilton. The production features a diverse cast and has won numerous awards including multiple Tony Awards, Grammy Awards, and the Pulitzer Prize for Drama. Don\'t miss your chance to be in "the room where it happens" as this revolutionary musical makes its Sydney debut.',
    category: 'Theatre',
    date: '2025-08-15',
    time: '7:30 PM',
    venue: 'Sydney Lyric Theatre',
    address: '55 Pirrama Rd, Pyrmont NSW 2009',
    image: 'https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$70 - $250',
    ticketUrl: 'https://hamiltonmusical.com.au',
    highlights: [
      'Australian premiere of the Broadway smash hit',
      'Winner of 11 Tony Awards and the Pulitzer Prize for Drama',
      'Featuring a diverse Australian cast',
      'Revolutionary blend of hip-hop and musical theatre',
      'Limited season - booking essential'
    ]
  },
  {
    id: '8',
    title: 'Sydney Harbor Kayak Tour',
    description: 'Paddle through Sydney Harbor at sunrise and experience the city\'s iconic landmarks from a unique perspective.',
    longDescription: 'Experience Sydney from a unique perspective with this guided kayaking tour of Sydney Harbor at sunrise. Launch from Lavender Bay and paddle past iconic landmarks including the Sydney Opera House and Sydney Harbor Bridge as the sun rises over the city. The tour is suitable for beginners and experienced kayakers alike, with expert guides providing instruction and sharing stories about Sydney\'s history and marine environment. Keep an eye out for local wildlife including sea birds and occasionally dolphins. The tour concludes with a light breakfast at a waterside café.',
    category: 'Outdoor',
    date: '2025-03-01',
    time: '5:30 AM - 8:30 AM',
    venue: 'Lavender Bay',
    address: 'Lavender Bay Boat Ramp, Lavender Crescent, Lavender Bay',
    image: 'https://images.pexels.com/photos/1430672/pexels-photo-1430672.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$129',
    ticketUrl: 'https://www.sydneyharborkayaks.com',
    highlights: [
      'Paddle past the Sydney Opera House and Harbor Bridge',
      'Spectacular sunrise views of the city skyline',
      'Expert guides with knowledge of local history and wildlife',
      'Suitable for beginners - no experience necessary',
      'Small groups of maximum 10 participants',
      'Includes light breakfast after the tour'
    ]
  },
  {
    id: '9',
    title: 'Taylor Swift: The Eras Tour',
    description: 'Global pop sensation Taylor Swift brings her record-breaking Eras Tour to Sydney.',
    longDescription: 'Global superstar Taylor Swift brings her record-breaking Eras Tour to Sydney\'s Accor Stadium for three nights only. This spectacular concert is a journey through Taylor\'s musical career, featuring songs from all of her albums including Fearless, Red, 1989, Reputation, Lover, Folklore, Evermore, and Midnights. The three-hour show includes multiple costume changes, elaborate stage designs, and state-of-the-art visual effects. With her biggest production to date, Taylor delivers an unforgettable night celebrating her evolution as an artist across different musical "eras."',
    category: 'Music',
    date: '2025-11-15',
    time: '7:00 PM',
    venue: 'Accor Stadium',
    address: 'Edwin Flack Ave, Sydney Olympic Park NSW 2127',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: '$150 - $450',
    ticketUrl: 'https://www.taylorswift.com/tour',
    highlights: [
      'Three-hour spectacular covering all of Taylor\'s musical eras',
      'Elaborate stage production with multiple sets and costume changes',
      'State-of-the-art visual effects and choreography',
      'Featuring songs from all of Taylor\'s albums',
      'Limited three-night engagement - high demand expected'
    ]
  }
];

// API functions
export const fetchEvents = async (): Promise<Event[]> => {
  // In a real app, this would be an API call
  // return axios.get('/api/events').then(res => res.data);
  
  // For this demo, return mock data after a short delay
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(MOCK_EVENTS);
    }, 800);
  });
};

export const fetchEventById = async (id: string): Promise<Event> => {
  // In a real app, this would be an API call
  // return axios.get(`/api/events/${id}`).then(res => res.data);
  
  // For this demo, return mock data after a short delay
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const event = MOCK_EVENTS.find(event => event.id === id);
      if (event) {
        resolve(event);
      } else {
        reject(new Error('Event not found'));
      }
    }, 800);
  });
};

export const fetchEventsByCategory = async (category: string): Promise<Event[]> => {
  // In a real app, this would be an API call
  // return axios.get(`/api/events/category/${category}`).then(res => res.data);
  
  // For this demo, filter mock data after a short delay
  return new Promise((resolve) => {
    setTimeout(() => {
      const filteredEvents = MOCK_EVENTS.filter(
        event => event.category.toLowerCase() === category.toLowerCase()
      );
      resolve(filteredEvents);
    }, 800);
  });
};