import React, { useState } from 'react';
import { useParams, useSearchParams, useNavigate } from 'react-router-dom';
import { useQuery } from 'react-query';
import { motion } from 'framer-motion';
import { Calendar, Clock, MapPin, Tag, Share2, Heart, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

import { fetchEventById } from '../services/api';
import EmailCaptureModal from '../components/events/EmailCaptureModal';

const EventDetailPage: React.FC = () => {
  const { eventId } = useParams<{ eventId: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(searchParams.get('action') === 'tickets');
  
  const { data: event, isLoading, error } = useQuery(
    ['event', eventId], 
    () => fetchEventById(eventId || '')
  );
  
  const handleGetTickets = () => {
    setShowModal(true);
  };
  
  const handleEmailSubmit = (email: string) => {
    // In a real app, you would save this email to your database
    console.log('Email captured:', email);
    
    // Redirect to the original ticket site
    if (event?.ticketUrl) {
      window.open(event.ticketUrl, '_blank');
    }
    
    setShowModal(false);
  };
  
  const handleCloseModal = () => {
    setShowModal(false);
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-24">
        <div className="animate-pulse">
          <div className="h-8 bg-surface-800 rounded w-1/2 mb-4"></div>
          <div className="h-6 bg-surface-800 rounded w-1/3 mb-8"></div>
          <div className="h-80 bg-surface-800 rounded mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="h-6 bg-surface-800 rounded mb-4"></div>
              <div className="h-4 bg-surface-800 rounded mb-2"></div>
              <div className="h-4 bg-surface-800 rounded mb-2"></div>
              <div className="h-4 bg-surface-800 rounded mb-6"></div>
            </div>
            <div>
              <div className="h-10 bg-surface-800 rounded mb-4"></div>
              <div className="h-40 bg-surface-800 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (error || !event) {
    return (
      <div className="container mx-auto px-4 py-24 text-center">
        <h1 className="text-2xl font-bold text-accent-400 mb-4">Event Not Found</h1>
        <p className="text-surface-300 mb-6">Sorry, we couldn't find the event you're looking for.</p>
        <button 
          onClick={() => navigate('/')}
          className="btn btn-primary"
        >
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <>
      <div className="pt-16">
        <div className="relative h-[50vh] min-h-[300px]">
          <div className="absolute inset-0 bg-primary-900/30 z-10"></div>
          <img 
            src={event.image} 
            alt={event.title} 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="container mx-auto px-4 py-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="glass-panel p-6 -mt-16 relative z-20 max-w-5xl mx-auto mb-12">
              <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
                <div>
                  <span className="inline-block bg-accent-500 text-white px-3 py-1 rounded-full text-sm font-medium mb-3">
                    {event.category}
                  </span>
                  <h1 className="text-3xl md:text-4xl font-bold mb-2">{event.title}</h1>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-surface-300">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-accent-400" />
                      <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-accent-400" />
                      <span>{event.time}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4 text-accent-400" />
                      <span>{event.venue}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <button className="p-2 rounded-full bg-surface-800 hover:bg-surface-700 transition-colors">
                    <Share2 className="h-5 w-5" />
                  </button>
                  <button className="p-2 rounded-full bg-surface-800 hover:bg-surface-700 transition-colors">
                    <Heart className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">About This Event</h2>
              <div className="text-surface-300 space-y-4">
                <p>{event.description}</p>
                <p>{event.longDescription}</p>
              </div>
              
              {event.highlights && (
                <>
                  <h3 className="text-xl font-bold mt-8 mb-4">Event Highlights</h3>
                  <ul className="list-disc pl-5 text-surface-300 space-y-2">
                    {event.highlights.map((highlight, index) => (
                      <li key={index}>{highlight}</li>
                    ))}
                  </ul>
                </>
              )}
            </div>
            
            <div>
              <div className="glass-panel p-6 sticky top-24">
                <h3 className="text-xl font-bold mb-4">Event Details</h3>
                
                <div className="space-y-4 mb-6">
                  <div>
                    <h4 className="text-sm text-surface-400 mb-1">Date & Time</h4>
                    <p className="text-surface-200">
                      {format(new Date(event.date), 'EEEE, MMMM d, yyyy')} • {event.time}
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm text-surface-400 mb-1">Location</h4>
                    <p className="text-surface-200">{event.venue}</p>
                    <p className="text-surface-400">{event.address}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm text-surface-400 mb-1">Price</h4>
                    <p className="text-surface-200">{event.price}</p>
                  </div>
                </div>
                
                <button 
                  className="btn btn-accent w-full mb-3 flex items-center justify-center gap-2"
                  onClick={handleGetTickets}
                >
                  Get Tickets
                  <ExternalLink className="h-4 w-4" />
                </button>
                
                <p className="text-xs text-surface-400 text-center">
                  You'll be redirected to the official ticketing website after sign-up
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {showModal && (
        <EmailCaptureModal 
          eventName={event.title} 
          onSubmit={handleEmailSubmit} 
          onClose={handleCloseModal} 
        />
      )}
    </>
  );
};

export default EventDetailPage;