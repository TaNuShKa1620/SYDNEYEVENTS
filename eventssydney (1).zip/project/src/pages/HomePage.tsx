import React, { useState } from 'react';
import { useQuery } from 'react-query';
import { motion } from 'framer-motion';
import { Search, Calendar, Tag, MapPin } from 'lucide-react';

import Hero from '../components/home/Hero';
import EventCard from '../components/events/EventCard';
import EventSkeleton from '../components/events/EventSkeleton';
import { fetchEvents } from '../services/api';

const HomePage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  
  const { data: events, isLoading, error } = useQuery('events', fetchEvents);
  
  const filteredEvents = events?.filter(event => {
    const matchesSearch = searchTerm === '' || 
      event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesCategory = selectedCategory === '' || event.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  const categories = [
    'Music', 'Arts', 'Sports', 'Food', 'Festival', 'Theatre', 'Comedy', 'Outdoor'
  ];

  return (
    <div>
      <Hero />
      
      <section className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <h2 className="text-3xl font-bold gradient-text">Discover Sydney Events</h2>
          
          <div className="relative">
            <input
              type="text"
              placeholder="Search events..."
              className="pl-10 pr-4 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white w-full md:w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-2.5 text-surface-400 h-5 w-5" />
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-8">
          <button 
            className={`btn ${selectedCategory === '' ? 'btn-accent' : 'bg-surface-800 text-surface-200'}`}
            onClick={() => setSelectedCategory('')}
          >
            All
          </button>
          {categories.map(category => (
            <button
              key={category}
              className={`btn ${selectedCategory === category ? 'btn-accent' : 'bg-surface-800 text-surface-200'}`}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, index) => (
              <EventSkeleton key={index} />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-accent-400 text-xl">Failed to load events</p>
          </div>
        ) : (
          <>
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {filteredEvents?.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <EventCard event={event} />
                </motion.div>
              ))}
            </motion.div>
            
            {filteredEvents?.length === 0 && (
              <div className="text-center py-10">
                <p className="text-xl text-surface-300">No events found matching your criteria</p>
              </div>
            )}
          </>
        )}
      </section>
      
      <section className="glass-panel container mx-auto px-6 py-12 my-12">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold mb-4">Stay Updated with Sydney's Hottest Events</h2>
          <p className="text-surface-300 mb-8">
            Subscribe to our newsletter and never miss out on the best events happening in Sydney
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-grow px-4 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white"
            />
            <button className="btn btn-accent">Subscribe</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;