import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Users, Lightbulb, Map, Mail } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="pt-16">
      <div className="relative h-[50vh] min-h-[300px]">
        <div className="absolute inset-0 bg-primary-900/70 z-10"></div>
        <img 
          src="https://images.pexels.com/photos/416676/pexels-photo-416676.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
          alt="Sydney Opera House" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-4">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About SydneyEvents</h1>
            <p className="text-xl text-surface-200 max-w-3xl mx-auto">
              Your ultimate guide to discovering the best events in Sydney
            </p>
          </div>
        </div>
      </div>
      
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 gradient-text">Our Mission</h2>
          <p className="text-lg text-surface-300 mb-6">
            At SydneyEvents, we're passionate about connecting people with the vibrant cultural, 
            entertainment, and community events that make Sydney one of the world's most exciting cities.
          </p>
          <p className="text-lg text-surface-300">
            Our mission is to provide a comprehensive, up-to-date, and beautifully designed platform 
            that makes it easy for residents and visitors to discover and attend the very best events 
            Sydney has to offer. From world-class concerts at the Opera House to community festivals 
            in local parks, we help you find experiences that match your interests and enrich your life.
          </p>
        </div>
      </section>
      
      <section className="glass-panel py-16 my-8">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-12 text-center gradient-text">What We Offer</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Calendar className="h-10 w-10 text-accent-400" />,
                title: 'Comprehensive Listings',
                description: 'Our platform automatically aggregates events from multiple sources to ensure you never miss out on what Sydney has to offer.'
              },
              {
                icon: <Users className="h-10 w-10 text-accent-400" />,
                title: 'Community Focus',
                description: 'We highlight both major events and smaller community gatherings to showcase the full diversity of Sydney\'s cultural landscape.'
              },
              {
                icon: <Lightbulb className="h-10 w-10 text-accent-400" />,
                title: 'Personalized Recommendations',
                description: 'Our smart filtering system helps you discover events that match your interests and preferences.'
              },
              {
                icon: <Map className="h-10 w-10 text-accent-400" />,
                title: 'Local Expertise',
                description: 'Our team of Sydney locals ensures that our curated selections truly represent the best the city has to offer.'
              }
            ].map((item, index) => (
              <motion.div 
                key={index}
                className="text-center p-6"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="flex justify-center mb-4">
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-surface-300">{item.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold mb-6 gradient-text">Our Story</h2>
          <p className="text-lg text-surface-300 mb-6">
            SydneyEvents was founded in 2025 by a group of tech enthusiasts and culture lovers who 
            were frustrated by how difficult it was to find comprehensive information about events in Sydney. 
            They often discovered amazing events only after they had already happened, or struggled to find 
            details about interesting happenings across the city's diverse neighborhoods.
          </p>
          <p className="text-lg text-surface-300 mb-6">
            Combining their technical expertise with their passion for Sydney's cultural scene, they created 
            an innovative platform that uses advanced web scraping technology to automatically aggregate 
            events from various sources, ensuring the most comprehensive and up-to-date listings available.
          </p>
          <p className="text-lg text-surface-300">
            Today, SydneyEvents has grown to become the go-to resource for both locals and tourists looking 
            to experience the best of what Sydney has to offer, with thousands of monthly users discovering 
            new experiences through our platform.
          </p>
        </div>
      </section>
      
      <section className="bg-primary-800 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Get In Touch</h2>
          <p className="text-lg text-surface-300 mb-8 max-w-2xl mx-auto">
            Have questions, suggestions, or want to collaborate with us? We'd love to hear from you!
          </p>
          
          <div className="flex items-center justify-center gap-3">
            <Mail className="h-6 w-6 text-accent-400" />
            <span className="text-xl">info@sydneyevents.com</span>
          </div>
          
          <div className="mt-12">
            <button className="btn btn-accent px-8 py-3">Contact Us</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;