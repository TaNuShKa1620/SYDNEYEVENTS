import React from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from 'react-query';
import { motion } from 'framer-motion';

import EventCard from '../components/events/EventCard';
import EventSkeleton from '../components/events/EventSkeleton';
import { fetchEventsByCategory } from '../services/api';

const categoryBanners: Record<string, string> = {
  music: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  arts: 'https://images.pexels.com/photos/1509534/pexels-photo-1509534.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  sports: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  food: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  festival: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  theatre: 'https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  comedy: 'https://images.pexels.com/photos/8047886/pexels-photo-8047886.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
  outdoor: 'https://images.pexels.com/photos/1061640/pexels-photo-1061640.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
};

const categoryDescriptions: Record<string, string> = {
  music: 'Discover the best concerts, live music, and performances in Sydney. From rock to classical, there\'s something for every music lover.',
  arts: 'Explore Sydney\'s vibrant arts scene with exhibitions, galleries, and cultural events that showcase local and international talent.',
  sports: 'Experience the thrill of sporting events in Sydney, from major league games to local competitions across various disciplines.',
  food: 'Indulge in Sydney\'s culinary delights with food festivals, tastings, and gastronomic events celebrating local and international cuisine.',
  festival: 'Join the excitement of Sydney\'s festivals celebrating culture, music, art, and community with events for all ages.',
  theatre: 'Experience the magic of live performances with Sydney\'s theatrical productions, from Broadway hits to independent shows.',
  comedy: 'Laugh out loud at Sydney\'s comedy events featuring local comics and international stars in venues across the city.',
  outdoor: 'Embrace the beauty of Sydney\'s natural surroundings with outdoor events, from beach activities to harbor celebrations.',
};

const CategoryPage: React.FC = () => {
  const { category } = useParams<{ category: string }>();
  const formattedCategory = category ? category.charAt(0).toUpperCase() + category.slice(1) : '';
  
  const { data: events, isLoading, error } = useQuery(
    ['events', category], 
    () => fetchEventsByCategory(category || '')
  );

  const bannerUrl = category ? categoryBanners[category] || categoryBanners.music : categoryBanners.music;
  const description = category ? categoryDescriptions[category] || '' : '';
  
  return (
    <div className="pt-16">
      <div className="relative h-[40vh] min-h-[250px]">
        <div className="absolute inset-0 bg-primary-900/50 z-10"></div>
        <img 
          src={bannerUrl} 
          alt={formattedCategory} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{formattedCategory} Events in Sydney</h1>
            <p className="text-lg text-surface-200">{description}</p>
          </div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-12">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, index) => (
              <EventSkeleton key={index} />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-10">
            <p className="text-accent-400 text-xl">Failed to load events</p>
          </div>
        ) : (
          <>
            <div className="mb-8 flex justify-between items-center">
              <h2 className="text-2xl font-bold">
                <span className="text-accent-400">{events?.length || 0}</span> events found
              </h2>
              
              <div className="flex items-center gap-2">
                <select className="px-3 py-2 rounded-lg bg-surface-800 border border-surface-700 text-white">
                  <option>Sort by: Date</option>
                  <option>Sort by: Popularity</option>
                  <option>Sort by: Price: Low to High</option>
                  <option>Sort by: Price: High to Low</option>
                </select>
              </div>
            </div>
            
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              {events?.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <EventCard event={event} />
                </motion.div>
              ))}
            </motion.div>
            
            {events?.length === 0 && (
              <div className="text-center py-10">
                <p className="text-xl text-surface-300">No events found in this category</p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;