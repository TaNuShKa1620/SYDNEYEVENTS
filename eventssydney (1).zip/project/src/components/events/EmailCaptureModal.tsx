import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

interface EmailCaptureModalProps {
  eventName: string;
  onSubmit: (email: string) => void;
  onClose: () => void;
}

const EmailCaptureModal: React.FC<EmailCaptureModalProps> = ({ eventName, onSubmit, onClose }) => {
  const [email, setEmail] = useState('');
  const [subscribe, setSubscribe] = useState(true);
  const [error, setError] = useState('');
  
  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      setError('Email is required');
      return;
    }
    
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }
    
    onSubmit(email);
  };
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-primary-900/80 backdrop-blur-sm">
      <motion.div 
        className="glass-panel w-full max-w-md relative"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        <button 
          className="absolute top-4 right-4 text-surface-400 hover:text-white"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </button>
        
        <div className="p-6">
          <h2 className="text-2xl font-bold mb-2">Almost there!</h2>
          <p className="text-surface-300 mb-6">
            Enter your email to get tickets for <span className="text-white font-medium">{eventName}</span>
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-surface-300 mb-1">
                Email Address
              </label>
              <input 
                type="email" 
                id="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError('');
                }}
                placeholder="your@email.com"
                className={`w-full px-4 py-2 rounded-lg bg-surface-800 border ${
                  error ? 'border-accent-500' : 'border-surface-700'
                } text-white focus:outline-none focus:ring-2 focus:ring-accent-400`}
              />
              {error && (
                <p className="mt-1 text-sm text-accent-500">{error}</p>
              )}
            </div>
            
            <div className="flex items-start">
              <div className="flex items-center h-5">
                <input
                  id="subscribe"
                  type="checkbox"
                  checked={subscribe}
                  onChange={(e) => setSubscribe(e.target.checked)}
                  className="h-4 w-4 rounded border-surface-700 bg-surface-800 text-accent-500 focus:ring-accent-400"
                />
              </div>
              <div className="ml-3">
                <label htmlFor="subscribe" className="text-sm text-surface-300">
                  Keep me updated about new events and special offers
                </label>
              </div>
            </div>
            
            <button
              type="submit"
              className="btn btn-accent w-full"
            >
              Continue to Tickets
            </button>
            
            <p className="text-xs text-surface-400 text-center">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </p>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default EmailCaptureModal;