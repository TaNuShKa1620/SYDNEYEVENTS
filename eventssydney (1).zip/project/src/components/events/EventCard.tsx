import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Calendar, MapPin, Tag, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { Event } from '../../types/event';

interface EventCardProps {
  event: Event;
}

const EventCard: React.FC<EventCardProps> = ({ event }) => {
  return (
    <motion.div 
      className="card h-full flex flex-col"
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <div className="relative">
        <img 
          src={event.image} 
          alt={event.title} 
          className="w-full aspect-video object-cover"
        />
        <div className="absolute top-3 right-3 bg-accent-500 text-white px-2 py-1 rounded-lg text-sm font-medium">
          {event.category}
        </div>
      </div>
      
      <div className="p-5 flex-grow flex flex-col">
        <div className="mb-4">
          <h3 className="text-xl font-bold mb-2 line-clamp-2">{event.title}</h3>
          <p className="text-surface-300 text-sm line-clamp-3">{event.description}</p>
        </div>
        
        <div className="mt-auto space-y-2 text-sm text-surface-300">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-accent-400" />
            <span>{format(new Date(event.date), 'EEEE, MMMM d, yyyy')}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-accent-400" />
            <span>{event.time}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-accent-400" />
            <span>{event.venue}</span>
          </div>
        </div>
        
        <div className="mt-4 flex gap-2">
          <Link 
            to={`/event/${event.id}`} 
            className="btn bg-surface-800 text-white flex-grow text-center"
          >
            View Details
          </Link>
          <Link 
            to={`/event/${event.id}?action=tickets`} 
            className="btn btn-accent text-center"
          >
            Get Tickets
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default EventCard;