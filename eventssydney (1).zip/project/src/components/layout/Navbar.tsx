import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Calendar, Search } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-primary-900/90 backdrop-blur-lg shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3">
            <Calendar className="h-7 w-7 text-accent-400" />
            <span className="font-bold text-2xl">SydneyEvents</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <nav className="flex items-center gap-6">
              <Link to="/" className={`nav-link ${isActive('/') ? 'active' : ''}`}>
                Home
              </Link>
              <Link to="/category/music" className={`nav-link ${isActive('/category/music') ? 'active' : ''}`}>
                Music
              </Link>
              <Link to="/category/arts" className={`nav-link ${isActive('/category/arts') ? 'active' : ''}`}>
                Arts
              </Link>
              <Link to="/category/sports" className={`nav-link ${isActive('/category/sports') ? 'active' : ''}`}>
                Sports
              </Link>
              <Link to="/about" className={`nav-link ${isActive('/about') ? 'active' : ''}`}>
                About
              </Link>
            </nav>
            
            <button className="p-2 rounded-full hover:bg-surface-800 transition-colors">
              <Search className="h-5 w-5" />
            </button>
          </div>
          
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-primary-900 border-t border-surface-800 py-4 px-4">
          <nav className="flex flex-col gap-2">
            <Link 
              to="/" 
              className={`py-2 px-3 rounded-lg ${isActive('/') ? 'bg-primary-800 text-white' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link 
              to="/category/music" 
              className={`py-2 px-3 rounded-lg ${isActive('/category/music') ? 'bg-primary-800 text-white' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Music
            </Link>
            <Link 
              to="/category/arts" 
              className={`py-2 px-3 rounded-lg ${isActive('/category/arts') ? 'bg-primary-800 text-white' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Arts
            </Link>
            <Link 
              to="/category/sports" 
              className={`py-2 px-3 rounded-lg ${isActive('/category/sports') ? 'bg-primary-800 text-white' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              Sports
            </Link>
            <Link 
              to="/about" 
              className={`py-2 px-3 rounded-lg ${isActive('/about') ? 'bg-primary-800 text-white' : ''}`}
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
          </nav>
          
          <div className="mt-4">
            <button className="btn bg-surface-800 text-white w-full flex items-center justify-center gap-2">
              <Search className="h-5 w-5" />
              Search Events
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;