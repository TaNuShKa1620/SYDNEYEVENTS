import React from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Mail, Phone, MapPin, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-surface-950 border-t border-surface-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Calendar className="h-6 w-6 text-accent-400" />
              <span className="font-bold text-xl">SydneyEvents</span>
            </div>
            <p className="text-surface-400 mb-6">
              Discover and enjoy the best events happening in Sydney. From concerts to exhibitions, we've got you covered.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-surface-400 hover:text-accent-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-surface-400 hover:text-accent-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-surface-400 hover:text-accent-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-surface-400 hover:text-accent-400 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-surface-400 hover:text-white transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/about" className="text-surface-400 hover:text-white transition-colors">About Us</Link>
              </li>
              <li>
                <Link to="/category/music" className="text-surface-400 hover:text-white transition-colors">Music Events</Link>
              </li>
              <li>
                <Link to="/category/arts" className="text-surface-400 hover:text-white transition-colors">Arts & Culture</Link>
              </li>
              <li>
                <Link to="/category/sports" className="text-surface-400 hover:text-white transition-colors">Sports Events</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/category/music" className="text-surface-400 hover:text-white transition-colors">Music</Link>
              </li>
              <li>
                <Link to="/category/arts" className="text-surface-400 hover:text-white transition-colors">Arts</Link>
              </li>
              <li>
                <Link to="/category/sports" className="text-surface-400 hover:text-white transition-colors">Sports</Link>
              </li>
              <li>
                <Link to="/category/food" className="text-surface-400 hover:text-white transition-colors">Food & Drink</Link>
              </li>
              <li>
                <Link to="/category/festival" className="text-surface-400 hover:text-white transition-colors">Festivals</Link>
              </li>
              <li>
                <Link to="/category/theatre" className="text-surface-400 hover:text-white transition-colors">Theatre</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold text-lg mb-4">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-accent-400 mt-0.5" />
                <span className="text-surface-400">123 Event Street, Sydney, NSW 2000, Australia</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-accent-400" />
                <span className="text-surface-400">+61 2 1234 5678</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-accent-400" />
                <span className="text-surface-400">info@sydneyevents.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-surface-800 mt-12 pt-6 flex flex-col md:flex-row md:items-center justify-between">
          <p className="text-surface-500 text-sm">
            &copy; {new Date().getFullYear()} SydneyEvents. All rights reserved.
          </p>
          <div className="flex flex-wrap gap-4 mt-4 md:mt-0">
            <Link to="/privacy" className="text-surface-500 hover:text-white text-sm transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-surface-500 hover:text-white text-sm transition-colors">
              Terms of Service
            </Link>
            <Link to="/cookies" className="text-surface-500 hover:text-white text-sm transition-colors">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;