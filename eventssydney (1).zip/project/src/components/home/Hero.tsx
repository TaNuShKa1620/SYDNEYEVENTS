import React from 'react';
import { motion } from 'framer-motion';
import { Calendar } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-[65vh] flex items-center overflow-hidden mt-20">
      <div className="absolute inset-0 bg-hero-pattern bg-cover bg-center">
        <div className="absolute inset-0 bg-gradient-to-b from-primary-900/80 to-primary-900"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Discover Sydney's <span className="gradient-text">Best Events</span>
          </h1>
          <p className="text-xl md:text-2xl text-surface-200 mb-8">
            Find the hottest concerts, festivals, exhibitions, and more happening in Sydney
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <button className="btn btn-accent flex items-center justify-center gap-2">
              <Calendar className="h-5 w-5" />
              Browse Events
            </button>
          </div>
          
          <div className="flex items-center gap-6">
            <motion.div 
              className="flex items-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              <div className="flex -space-x-2">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className="h-8 w-8 rounded-full bg-accent-400 border-2 border-primary-900 flex items-center justify-center text-xs font-bold">
                    {String.fromCharCode(65 + i)}
                  </div>
                ))}
              </div>
              <span className="ml-3 text-surface-200">1,000+ events this month</span>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.5 }}
              className="hidden md:block h-8 w-[1px] bg-surface-700"
            ></motion.div>
            
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9, duration: 0.5 }}
              className="hidden md:flex items-center gap-1"
            >
              <span className="text-accent-400 font-bold">Live updates</span>
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-accent-500"></span>
              </span>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Hero;