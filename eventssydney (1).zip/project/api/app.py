from flask import Flask, request, jsonify, abort
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import json
import time
import threading
import os
import re
import logging
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

# Data storage
EVENTS_DATA_FILE = 'events_data.json'
EMAIL_DATA_FILE = 'email_data.json'

# Default events in case scraping fails
DEFAULT_EVENTS = []

# Global variables
events_data = []
last_scrape_time = None
scrape_lock = threading.Lock()
scrape_interval = 3600  # Time in seconds between scrapes (1 hour)

def load_data():
    """Load events data from file if it exists"""
    global events_data
    try:
        if os.path.exists(EVENTS_DATA_FILE):
            with open(EVENTS_DATA_FILE, 'r') as f:
                events_data = json.load(f)
                logger.info(f"Loaded {len(events_data)} events from file")
        else:
            events_data = DEFAULT_EVENTS
            logger.info("No existing data file found, using default events")
    except Exception as e:
        logger.error(f"Error loading data: {str(e)}")
        events_data = DEFAULT_EVENTS

def save_data():
    """Save events data to file"""
    try:
        with open(EVENTS_DATA_FILE, 'w') as f:
            json.dump(events_data, f)
        logger.info(f"Saved {len(events_data)} events to file")
    except Exception as e:
        logger.error(f"Error saving data: {str(e)}")

def save_email(email, event_id):
    """Save captured email to file"""
    try:
        emails = []
        if os.path.exists(EMAIL_DATA_FILE):
            with open(EMAIL_DATA_FILE, 'r') as f:
                emails = json.load(f)
        
        emails.append({
            'email': email,
            'event_id': event_id,
            'timestamp': datetime.now().isoformat(),
            'subscribed': True
        })
        
        with open(EMAIL_DATA_FILE, 'w') as f:
            json.dump(emails, f)
        logger.info(f"Saved email: {email} for event {event_id}")
        return True
    except Exception as e:
        logger.error(f"Error saving email: {str(e)}")
        return False

def scrape_eventbrite():
    """Scrape events from Eventbrite for Sydney"""
    events = []
    try:
        url = "https://www.eventbrite.com/d/australia--sydney/events/"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find event cards
        event_cards = soup.select('div[data-testid="event-card"]')
        
        for i, card in enumerate(event_cards):
            try:
                # Extract event details
                title_elem = card.select_one('h2')
                date_elem = card.select_one('span[data-testid="event-card-date"]')
                venue_elem = card.select_one('div[data-testid="event-card-venue"]')
                image_elem = card.select_one('img')
                link_elem = card.select_one('a[href*="/e/"]')
                
                if not title_elem or not date_elem:
                    continue
                
                title = title_elem.text.strip()
                date_str = date_elem.text.strip()
                venue = venue_elem.text.strip() if venue_elem else "Sydney"
                image_url = image_elem['src'] if image_elem and 'src' in image_elem.attrs else ""
                event_url = "https://www.eventbrite.com" + link_elem['href'] if link_elem else ""
                
                # Determine category based on title keywords
                category = determine_category(title)
                
                # Extract price (this is a simplification)
                price = "Free" if "free" in title.lower() else "$25 - $80"
                
                # Create event object
                event = {
                    'id': f"eb-{i}",
                    'title': title,
                    'description': f"Join us for {title} in Sydney. Don't miss this exciting event!",
                    'longDescription': f"Join us for {title} in Sydney. This event promises to be an unforgettable experience with something for everyone. Located at {venue}, it's the perfect opportunity to enjoy Sydney's vibrant cultural scene. Don't miss out on this exciting event!",
                    'category': category,
                    'date': parse_date(date_str),
                    'time': extract_time(date_str),
                    'venue': venue,
                    'address': f"{venue}, Sydney NSW, Australia",
                    'image': image_url if image_url else "https://images.pexels.com/photos/2747449/pexels-photo-2747449.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                    'price': price,
                    'ticketUrl': event_url,
                    'highlights': generate_highlights(title, category)
                }
                
                events.append(event)
                logger.info(f"Scraped Eventbrite event: {title}")
            except Exception as e:
                logger.error(f"Error parsing Eventbrite event card: {str(e)}")
                continue
        
        logger.info(f"Successfully scraped {len(events)} events from Eventbrite")
    except Exception as e:
        logger.error(f"Error scraping Eventbrite: {str(e)}")
    
    return events

def scrape_timeout():
    """Scrape events from Timeout Sydney"""
    events = []
    try:
        url = "https://www.timeout.com/sydney/things-to-do/things-to-do-in-sydney-this-weekend"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find event cards
        event_cards = soup.select('article._articleCard_1wkwb_1')
        
        for i, card in enumerate(event_cards):
            try:
                # Extract event details
                title_elem = card.select_one('h3')
                desc_elem = card.select_one('p')
                image_elem = card.select_one('img')
                link_elem = card.select_one('a')
                
                if not title_elem:
                    continue
                
                title = title_elem.text.strip()
                description = desc_elem.text.strip() if desc_elem else f"Exciting event in Sydney: {title}"
                image_url = image_elem['src'] if image_elem and 'src' in image_elem.attrs else ""
                event_url = "https://www.timeout.com" + link_elem['href'] if link_elem else ""
                
                # Generate a random date in the next 30 days
                event_date = (datetime.now() + timedelta(days=i % 30 + 1)).strftime('%Y-%m-%d')
                
                # Determine category based on title keywords
                category = determine_category(title)
                
                # Create event object
                event = {
                    'id': f"to-{i}",
                    'title': title,
                    'description': description,
                    'longDescription': f"{description} This is one of Sydney's most anticipated events, featuring activities for all ages and interests. Come experience the vibrant atmosphere and make unforgettable memories.",
                    'category': category,
                    'date': event_date,
                    'time': f"{7 + (i % 12)}:00 PM",
                    'venue': random_sydney_venue(),
                    'address': "Sydney NSW, Australia",
                    'image': image_url if image_url and image_url.startswith('http') else "https://images.pexels.com/photos/2747449/pexels-photo-2747449.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                    'price': "Free" if i % 3 == 0 else f"${15 + i * 5}",
                    'ticketUrl': event_url,
                    'highlights': generate_highlights(title, category)
                }
                
                events.append(event)
                logger.info(f"Scraped Timeout event: {title}")
            except Exception as e:
                logger.error(f"Error parsing Timeout event card: {str(e)}")
                continue
        
        logger.info(f"Successfully scraped {len(events)} events from Timeout")
    except Exception as e:
        logger.error(f"Error scraping Timeout: {str(e)}")
    
    return events

def determine_category(title):
    """Determine category based on title keywords"""
    title_lower = title.lower()
    
    if any(word in title_lower for word in ['music', 'concert', 'band', 'symphony', 'opera', 'jazz', 'festival']):
        return 'Music'
    elif any(word in title_lower for word in ['art', 'exhibition', 'gallery', 'museum']):
        return 'Arts'
    elif any(word in title_lower for word in ['sport', 'game', 'match', 'racing', 'tournament']):
        return 'Sports'
    elif any(word in title_lower for word in ['food', 'wine', 'dining', 'taste', 'culinary']):
        return 'Food'
    elif any(word in title_lower for word in ['comedy', 'laugh', 'stand-up']):
        return 'Comedy'
    elif any(word in title_lower for word in ['theatre', 'play', 'drama', 'musical']):
        return 'Theatre'
    elif any(word in title_lower for word in ['outdoor', 'park', 'beach', 'hike', 'tour']):
        return 'Outdoor'
    else:
        # Randomly assign a category if no keywords match
        import random
        categories = ['Music', 'Arts', 'Sports', 'Food', 'Comedy', 'Theatre', 'Outdoor', 'Festival']
        return random.choice(categories)

def parse_date(date_str):
    """Convert various date formats to YYYY-MM-DD"""
    try:
        # Handle various date formats
        today = datetime.now()
        
        if 'today' in date_str.lower():
            return today.strftime('%Y-%m-%d')
        elif 'tomorrow' in date_str.lower():
            return (today + timedelta(days=1)).strftime('%Y-%m-%d')
        
        # Try to extract month and day
        months = {
            'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'may': 5, 'jun': 6,
            'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12
        }
        
        # Look for patterns like "May 15" or "15 May"
        for month_name, month_num in months.items():
            pattern1 = fr'{month_name}\w* (\d+)'  # "May 15"
            pattern2 = fr'(\d+)\w* {month_name}'  # "15 May"
            
            match1 = re.search(pattern1, date_str.lower())
            match2 = re.search(pattern2, date_str.lower())
            
            if match1:
                day = int(match1.group(1))
                year = today.year if month_num >= today.month else today.year + 1
                return f"{year}-{month_num:02d}-{day:02d}"
            elif match2:
                day = int(match2.group(1))
                year = today.year if month_num >= today.month else today.year + 1
                return f"{year}-{month_num:02d}-{day:02d}"
        
        # If we can't parse the date, return a date in the next month
        return (today + timedelta(days=30)).strftime('%Y-%m-%d')
    except Exception as e:
        logger.error(f"Error parsing date '{date_str}': {str(e)}")
        # Return a fallback date
        return (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')

def extract_time(date_str):
    """Extract time from date string or generate a reasonable event time"""
    try:
        # Look for time pattern like "7:30 PM" or "19:30"
        time_pattern = r'(\d{1,2}):?(\d{2})?\s*(am|pm|AM|PM)?'
        match = re.search(time_pattern, date_str)
        
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2)) if match.group(2) else 0
            period = match.group(3).upper() if match.group(3) else None
            
            if period == 'PM' and hour < 12:
                hour += 12
            elif period == 'AM' and hour == 12:
                hour = 0
            
            return f"{hour}:{minute:02d} {'AM' if hour < 12 else 'PM'}"
        
        # If no time found, generate a reasonable event time
        import random
        hour = random.randint(10, 20)  # Events typically between 10 AM and 8 PM
        minute = random.choice([0, 30])  # Events typically start on the hour or half-hour
        
        return f"{hour if hour <= 12 else hour-12}:{minute:02d} {'AM' if hour < 12 else 'PM'}"
    except Exception as e:
        logger.error(f"Error extracting time from '{date_str}': {str(e)}")
        return "7:00 PM"  # Default time

def random_sydney_venue():
    """Return a random Sydney venue name"""
    venues = [
        "Sydney Opera House",
        "State Theatre Sydney",
        "Capitol Theatre",
        "ICC Sydney",
        "The Enmore Theatre",
        "Sydney Town Hall",
        "The Star Sydney",
        "Royal Botanic Garden",
        "Darling Harbour",
        "Luna Park Sydney",
        "Taronga Zoo",
        "Art Gallery of NSW",
        "Carriageworks",
        "The Domain",
        "Hordern Pavilion",
        "Sydney Olympic Park"
    ]
    
    import random
    return random.choice(venues)

def generate_highlights(title, category):
    """Generate event highlights based on title and category"""
    highlights = []
    
    # Add category-specific highlights
    if category == 'Music':
        highlights = [
            "Live performances from top artists",
            "State-of-the-art sound system",
            "VIP seating options available",
            "Food and drinks available for purchase"
        ]
    elif category == 'Arts':
        highlights = [
            "Featuring works from renowned artists",
            "Interactive exhibits for all ages",
            "Guided tours available",
            "Limited-time exhibition"
        ]
    elif category == 'Sports':
        highlights = [
            "World-class athletes competing",
            "Premium viewing areas",
            "Food and beverage concessions",
            "Family-friendly entertainment"
        ]
    elif category == 'Food':
        highlights = [
            "Tastings from Sydney's best restaurants",
            "Live cooking demonstrations",
            "Wine and craft beer pairings",
            "Meet celebrity chefs"
        ]
    elif category == 'Comedy':
        highlights = [
            "Lineup of hilarious performers",
            "Intimate venue setting",
            "Full bar service available",
            "Ages 18+ unless noted"
        ]
    elif category == 'Theatre':
        highlights = [
            "Award-winning production",
            "Stunning set design and costumes",
            "Professional cast of performers",
            "Limited season - book early"
        ]
    elif category == 'Outdoor':
        highlights = [
            "Beautiful Sydney scenery",
            "Suitable for all fitness levels",
            "Experienced guides",
            "Equipment provided"
        ]
    elif category == 'Festival':
        highlights = [
            "Multiple stages and performance areas",
            "Wide variety of food vendors",
            "Family-friendly activities",
            "Local and international performers"
        ]
    
    # Add a specific highlight based on the title
    title_highlight = f"Don't miss: {title}"
    highlights.append(title_highlight)
    
    return highlights

def perform_scraping():
    """Perform the scraping of events from all sources"""
    global events_data, last_scrape_time
    
    with scrape_lock:
        logger.info("Starting event scraping...")
        
        # Scrape from multiple sources
        eventbrite_events = scrape_eventbrite()
        timeout_events = scrape_timeout()
        
        # Combine events from all sources
        all_events = eventbrite_events + timeout_events
        
        if all_events:
            # Update global events data
            events_data = all_events
            last_scrape_time = datetime.now()
            
            # Save to file
            save_data()
            logger.info(f"Scraping completed. Found {len(events_data)} events.")
        else:
            logger.warning("No events found during scraping.")

def scheduled_scraping():
    """Perform scheduled scraping at regular intervals"""
    while True:
        perform_scraping()
        time.sleep(scrape_interval)

@app.route('/api/events', methods=['GET'])
def get_events():
    """API endpoint to get all events"""
    category = request.args.get('category')
    
    if category:
        filtered_events = [e for e in events_data if e['category'].lower() == category.lower()]
        return jsonify(filtered_events)
    
    return jsonify(events_data)

@app.route('/api/events/<event_id>', methods=['GET'])
def get_event(event_id):
    """API endpoint to get a specific event by ID"""
    event = next((e for e in events_data if e['id'] == event_id), None)
    
    if not event:
        abort(404, description="Event not found")
    
    return jsonify(event)

@app.route('/api/events/category/<category>', methods=['GET'])
def get_events_by_category(category):
    """API endpoint to get events by category"""
    filtered_events = [e for e in events_data if e['category'].lower() == category.lower()]
    return jsonify(filtered_events)

@app.route('/api/email', methods=['POST'])
def save_user_email():
    """API endpoint to save user email"""
    data = request.json
    
    if not data or 'email' not in data or 'eventId' not in data:
        abort(400, description="Missing required fields")
    
    success = save_email(data['email'], data['eventId'])
    
    if not success:
        abort(500, description="Failed to save email")
    
    return jsonify({"success": True})

@app.route('/api/status', methods=['GET'])
def get_status():
    """API endpoint to check the status of the scraper"""
    return jsonify({
        "status": "running",
        "events_count": len(events_data),
        "last_scrape": last_scrape_time.isoformat() if last_scrape_time else None,
        "next_scrape": (last_scrape_time + timedelta(seconds=scrape_interval)).isoformat() if last_scrape_time else None
    })

if __name__ == '__main__':
    # Load existing data
    load_data()
    
    # Start background scraper thread
    scraper_thread = threading.Thread(target=scheduled_scraping, daemon=True)
    scraper_thread.start()
    
    # Start Flask app
    app.run(host='0.0.0.0', port=5000, debug=False)