/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'primary': {
          50: '#f0f4ff',
          100: '#dbe4ff',
          200: '#bccaff',
          300: '#8fa5ff',
          400: '#6074ff',
          500: '#4147fc',
          600: '#3329f0',
          700: '#2d1b69',
          800: '#1e1650',
          900: '#121826',
        },
        'accent': {
          300: '#FF8787',
          400: '#FF6B6B',
          500: '#FA5252',
          600: '#E03131',
        },
        'surface': {
          50: '#f8fafc',
          100: '#f1f5f9',
          200: '#e2e8f0',
          800: '#1e293b',
          900: '#0f172a',
          950: '#020617',
        }
      },
      animation: {
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      backgroundImage: {
        'hero-pattern': "url('https://images.pexels.com/photos/1123972/pexels-photo-1123972.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')",
      }
    },
  },
  plugins: [],
};